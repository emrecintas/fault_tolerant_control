# Internal parameters and loggin api App example for Crazyflie 2.X

This folder contains the app layer application for the Crazyflie to use the internal logging and parameter API, which can be monitord in the console tab of the [cfclient](https://github.com/bitcraze/crazyflie-clients-python). 

See App layer API guide and build instructions [here](https://www.bitcraze.io/documentation/repository/crazyflie-firmware/master/userguides/app_layer/)