# Hello file tree App for Crazyflie 2.X

This folder contains an app layer application for the Crazyflie to show how to work with a file tree in Out Of Tree builds.
It prints the classic hello world debug message, which can be read in the console tab of the [cfclient](https://github.com/bitcraze/crazyflie-clients-python).

See App layer API guide and build instructions [here](https://www.bitcraze.io/documentation/repository/crazyflie-firmware/master/userguides/app_layer/)