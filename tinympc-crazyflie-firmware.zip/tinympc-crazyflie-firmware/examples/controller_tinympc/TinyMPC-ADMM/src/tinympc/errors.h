#ifndef ERRORS_H
# define ERRORS_H

# ifdef __cplusplus
extern "C" {
# endif // ifdef __cplusplus


// To fill in error handling routines


# ifdef __cplusplus
}
# endif // ifdef __cplusplus

#endif // ifndef ERRORS_H
