---
title: uSD card - MEM_TYPE_USD
page_id: mem_type_usd
---

The uSD card memory mapping can be used to read data from the SD card, write operations are not supported.

Reads are mapped to the current file, and only works if the logging is stopped.
