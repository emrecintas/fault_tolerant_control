---
title: Trajectory - MEM_TYPE_TRAJ
page_id: mem_type_traj
---

The trajectory memory is mapped directly to the memory used by [the high level commander](/docs/functional-areas/sensor-to-control/commanders_setpoints/#high-level-commander)
to store trajectories. The format is described in the [trajectory formats](/docs/functional-areas/trajectory_formats.md)
section.
