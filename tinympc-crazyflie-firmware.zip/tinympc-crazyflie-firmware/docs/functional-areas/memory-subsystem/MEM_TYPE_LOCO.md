---
title: Loco Positioning System 1 - MEM_TYPE_LOCO
page_id: mem_type_loco
---

This implementation is obsolete and remains for backwards compatibility.
