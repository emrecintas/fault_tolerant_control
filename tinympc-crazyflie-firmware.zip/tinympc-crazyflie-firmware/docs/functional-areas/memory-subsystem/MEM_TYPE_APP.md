---
title: Generic application memory - MEM_TYPE_APP
page_id: mem_type_app
---

This memory can be used by applications and the memory
layout is application specific.
