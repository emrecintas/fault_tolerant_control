---
title: Functional areas
page_id: functional_areas_index
sort_order: 3
---

This section describes the functionality of various parts of the system.

{% sub_page_menu %}
